
package com.example.wetherapp.models;

import java.util.LinkedHashMap;
import java.util.Map;



public class WeatherModel {

    private String cod;
    private Integer message;
    private Integer cnt;
    private java.util.List<com.example.wetherapp.models.List> list;
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public Integer getMessage() {
        return message;
    }

    public void setMessage(Integer message) {
        this.message = message;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }

    public java.util.List<com.example.wetherapp.models.List> getList() {
        return list;
    }

    public void setList(java.util.List<com.example.wetherapp.models.List> list) {
        this.list = list;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
